#!/bin/sh

AndoridNDKRoot=/d/android_devel/Android/Sdk/ndk/28.0.12674087
AndroidToolChain=${AndoridNDKRoot}/toolchains/llvm/prebuilt/windows-x86_64
AndroidAPI=21

if [ ${AndroidAPI} -ge 35 ]; then
    AndroidTarget_list="
        armv7a-linux-androideabi
        i686-linux-android
        "
else
    AndroidTarget_list="
        armv7a-linux-androideabi
        i686-linux-android
        "
fi


prefix_root_dir=stage32

rm -fr ${prefix_root_dir}

prefix_dir=${prefix_root_dir}/luajit210-beta

prefix_dir_include=${prefix_dir}/include
mkdir -p ${prefix_dir_include}

cp -f *.h ${prefix_dir_include}/


for var_target in ${AndroidTarget_list} 
do
    echo "make" ${var_target}

    sh luajit_make_android_yggr.sh ${AndoridNDKRoot} ${AndroidToolChain} ${var_target} ${AndroidAPI} ${prefix_dir} -m32

done



