.. |version| replace:: 0.9.1
