﻿using System;
using LuaInterface;

public static class TestProtol
{
    [LuaByteBufferAttribute]
    public static byte[] data; 
}
