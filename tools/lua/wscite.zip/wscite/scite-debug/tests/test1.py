def one(x):
	print x
	
def two(x,y):
	one(x)
	one(y)
	
two(10,20)
