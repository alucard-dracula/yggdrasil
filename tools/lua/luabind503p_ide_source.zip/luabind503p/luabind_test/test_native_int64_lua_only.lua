

local function test_u64()
	print("lua", 1 << 40)
end


test_u64()

