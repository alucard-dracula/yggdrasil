﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("MongoDB.Libmongocrypt.Test")]
[assembly: InternalsVisibleTo("MongoDB.Libmongocrypt.Test32")]
