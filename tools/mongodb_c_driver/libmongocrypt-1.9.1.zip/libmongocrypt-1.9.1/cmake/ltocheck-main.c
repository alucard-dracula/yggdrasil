extern int
answer (int, int);

int
main ()
{
   int a = answer (3, 4);
   return a != 7;
}
