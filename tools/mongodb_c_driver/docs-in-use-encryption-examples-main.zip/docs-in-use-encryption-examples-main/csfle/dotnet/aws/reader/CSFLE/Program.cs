using Insert;
using Key;

namespace Run
{
    class Run
    {
        static void Main(string[] args)
        {
            MakeDataKey.MakeKey();
            InsertEncryptedDocument.Insert();
        }
    }
}
