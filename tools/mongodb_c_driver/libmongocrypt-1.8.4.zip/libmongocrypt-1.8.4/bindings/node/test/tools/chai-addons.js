'use strict';

// configure chai
const chai = require('chai');
chai.use(require('sinon-chai'));
chai.use(require('chai-subset'));

chai.config.truncateThreshold = 0;
