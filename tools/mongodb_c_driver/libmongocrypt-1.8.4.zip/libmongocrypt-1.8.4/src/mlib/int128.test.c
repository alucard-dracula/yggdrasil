#include "./int128.h"

// This file checks for C compilability. Other tests are defined in .test.cpp
