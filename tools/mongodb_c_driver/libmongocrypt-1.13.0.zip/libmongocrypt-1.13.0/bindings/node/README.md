###  The Node.js Bindings Have Moved!

#### https://github.com/mongodb-js/mongodb-client-encryption

They can still be found at the same npm package:
- https://www.npmjs.com/package/mongodb-client-encryption
