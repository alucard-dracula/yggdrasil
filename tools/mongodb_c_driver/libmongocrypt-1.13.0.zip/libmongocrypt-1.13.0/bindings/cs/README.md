### The C# bindings have been moved!

#### https://github.com/mongodb/mongo-csharp-driver/tree/main/src/MongoDB.Driver.Encryption

They have been renamed from ```MongoDB.Libmongocrypt``` to ```MongoDB.Driver.Encryption``` 
and can be found on nuget here: https://www.nuget.org/packages/MongoDB.Driver.Encryption/
