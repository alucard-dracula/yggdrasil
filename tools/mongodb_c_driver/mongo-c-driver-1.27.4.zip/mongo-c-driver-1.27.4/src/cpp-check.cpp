/**
 * The sole purpose of this file is to check that the mongoc headers can be
 * included in a C++ file without error.
 */
#include <bson/bson.h>
#include <mongoc/mongoc.h>
