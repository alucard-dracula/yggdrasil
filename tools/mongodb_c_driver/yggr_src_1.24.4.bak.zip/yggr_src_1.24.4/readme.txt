all name delete rename to deletor

mend mongoc-uri-private.h line 36 BSON_BEGIN_DECLS to BSON_END_DECLS