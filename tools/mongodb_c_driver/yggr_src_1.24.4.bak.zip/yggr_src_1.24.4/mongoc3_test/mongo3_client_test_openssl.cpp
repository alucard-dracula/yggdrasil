// mongo_gridfs_org_test.cpp

#include <iostream>

#include <mongoc.h>
#include <stdio.h>
#include <stdlib.h>

#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/engine.h>
#include <openssl/conf.h>
#include <openssl/bio.h>

#ifdef _MSC_VER
#	ifdef _DEBUG
#		pragma comment(lib, "libbson-vc100-d.lib")
#		pragma comment(lib, "libyajl-vc100-d.lib")
#		pragma comment(lib, "libmongoc-vc100-d.lib")
#	else
#		pragma comment(lib, "libbson-vc100.lib")
#		pragma comment(lib, "libyajl-vc100.lib")
#		pragma comment(lib, "libmongoc-vc100.lib")
#	endif // _DEBUG
#	pragma comment(lib, "ssleay32.lib")
#	pragma comment(lib, "libeay32.lib")
#	pragma comment(lib, "ws2_32.lib")
#endif // _MSC_VER

#ifdef _MSC_VER
#	include <vld.h>
#endif // _MSC_VER

inline static bool create_network_context(void)
{
#if defined(WIN32) || defined(WIN64) || defined(WINDOWS)
	WSADATA out;
    ::WSAStartup(MAKEWORD(2,2), &out);

	return out.wVersion == 0x0202;
#else
	return true;
#endif // defined(WIN32) || defined(WIN64) || defined(WINDOWS)
}

inline static bool destroy_network_context(void)
{
#if defined(WIN32) || defined(WIN64) || defined(WINDOWS)
	::WSACleanup();
#endif // defined(WIN32) || defined(WIN64) || defined(WINDOWS)
	return true;
}

inline static void create_openssl_context(void)
{
	SSL_library_init ();
	SSL_load_error_strings ();
	ERR_load_BIO_strings ();
	OpenSSL_add_all_algorithms ();
}

inline static void destroy_openssl_context(void)
{
	ENGINE_cleanup();
	CONF_modules_unload(1);
	EVP_cleanup();
	SSL_COMP_free_compression_methods();
	ERR_free_strings();
	CRYPTO_cleanup_all_ex_data();
	ERR_remove_state(0);
}

void test_database(void)
{
	mongoc_client_t *client = 0;
	mongoc_collection_t *collection = 0;
	mongoc_cursor_t *cursor = 0;
	bson_error_t error;
	const bson_t *doc = 0;
	const char *uristr = "mongodb://127.0.0.1:10098/?ssl=true";
	const char *collection_name = "foo";
	bson_t query;
	char *str = 0;

	client = mongoc_client_new (uristr);

	if (!client) {
		fprintf (stderr, "Failed to parse URI.\n");
		return;
	}


	mongoc_ssl_opt_t ssl_opts = { 0 };


	std::string str_pem_file = "mongo.pem";
	ssl_opts.pem_file = str_pem_file.c_str(); // warning this is not copy
	ssl_opts.pem_pwd = "";
	ssl_opts.ca_file = "camongodb.pem";
	ssl_opts.ca_dir = "./";
	ssl_opts.weak_cert_validation = true;
	mongoc_client_set_ssl_opts(client, &ssl_opts);

	mongoc_database_t* pdb = mongoc_client_get_database(client, "test_ssl_db");

	mongoc_database_drop(pdb, &error); // if the mongoc_database_drop is called, the second EVP_cleanup crush

	mongoc_database_destroy(pdb);
	mongoc_client_destroy (client);
}

int main (int argc, char *argv[])
{
	create_network_context();
	create_openssl_context();
	::mongoc_init();

	mongoc_cleanup();
	destroy_openssl_context();
	destroy_network_context();

	create_network_context();
	create_openssl_context();
	::mongoc_init();

	test_database();

	mongoc_cleanup();
	destroy_openssl_context();
	destroy_network_context();

	std::cout << "end" << std::endl;
	char cc = 0;
	std::cin >> cc;
	return 0;
}
