// mongo_gridfs_org_test.cpp

#include <iostream>

#include <mongoc.h>
#include <stdio.h>
#include <stdlib.h>

#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/engine.h>
#include <openssl/conf.h>
#include <openssl/bio.h> 

#ifdef _MSC_VER
#	pragma comment(lib, "libbson-vc100-d.lib")
#	pragma comment(lib, "libmongoc-vc100-d.lib")
#	pragma comment(lib, "libyajl-vc100-d.lib")
#	pragma comment(lib, "ssleay32.lib")
#	pragma comment(lib, "libeay32.lib")
#	pragma comment(lib, "ws2_32.lib")
#endif // _MSC_VER

#ifdef _MSC_VER
#	include <vld.h>
#endif // _MSC_VER

void init_ssl(void)
{
	SSL_library_init ();
	SSL_load_error_strings ();
	ERR_load_BIO_strings ();
	OpenSSL_add_all_algorithms ();
}

void clean_ssl(void)
{
	ENGINE_cleanup();
	CONF_modules_unload(1);
	EVP_cleanup();
	SSL_COMP_free_compression_methods();
	ERR_free_strings();
	CRYPTO_cleanup_all_ex_data();
	ERR_remove_state(0);
}

int main (int argc, char *argv[])
{
	mongoc_client_pool_t *client_pool = 0;
	const char *uristr = "mongodb://127.0.0.1:10098/?ssl=true";

#ifdef _WIN32
   {
      WORD wVersionRequested;
      WSADATA wsaData;
      int err;

      wVersionRequested = MAKEWORD (2, 2);

      err = WSAStartup (wVersionRequested, &wsaData);

      /* check the version perhaps? */

      BSON_ASSERT (err == 0);
   }
#endif //_WIN32

	init_ssl();
	mongoc_init ();

	mongoc_uri_t* puri = mongoc_uri_new(uristr);

	client_pool = mongoc_client_pool_new(puri);

	if (!client_pool) {
		fprintf (stderr, "Failed to parse URI.\n");
		return EXIT_FAILURE;
	}
	
	mongoc_ssl_opt_t ssl_opts = { 0 };

	std::string str_pem_file = "mongo.pem";
	ssl_opts.pem_file = str_pem_file.c_str(); // warning this is not copy
	ssl_opts.pem_pwd = "";
	ssl_opts.ca_file = "camongodb.pem";
	ssl_opts.ca_dir = "./";
	ssl_opts.weak_cert_validation = true;

	mongoc_client_pool_set_ssl_opts(client_pool, &ssl_opts);

	mongoc_client_pool_destroy(client_pool);
	mongoc_uri_destroy(puri);

	mongoc_cleanup ();
	clean_ssl();

	//ENGINE_cleanup();
	//CONF_modules_unload(1);
	//EVP_cleanup();
	//SSL_COMP_free_compression_methods();
	//ERR_free_strings();
	//CRYPTO_cleanup_all_ex_data();
	//ERR_remove_state(0);

	
#ifdef _WIN32
   WSACleanup ();
#endif

	char cc = 0;
	std::cin >> cc;

	return EXIT_SUCCESS;
}