//mongo3_client_test.cpp

#define MONGOC_COMPILATION

#include <iostream>

#include <mongoc.h>

#include <mongoc-client-private.h>
#include <mongoc-uri-private.h>

#pragma comment(lib, "libmongoc-vc100-d.lib")
#pragma comment(lib, "ssleay32.lib")
#pragma comment(lib, "libeay32.lib")

#ifdef _MAC_VER
#	include <vld.h>
#endif // _MAC_VER


int main(int argc, char* argv[])
{
	mongoc_init();


	//std::cout << sizeof(mongoc_client_t) << std::endl;
	//mongoc_uri_t* puri = mongoc_uri_new("mongodb://alucard:123456@127.0.0.1/test");
	//mongoc_uri_t* puri = mongoc_uri_new("mongodb://db1.example.com,db2.example.com:2500/?replicaSet=test");
	mongoc_client_t* pclient = mongoc_client_new("mongodb://xy:123456@127.0.0.1/test");

	{
		char cc =0;
		std::cin >> cc;
	}

	mongoc_client_destroy(pclient);
	//mongoc_uri_destroy(puri);
	{
		char cc = 0;
		std::cin >> cc;
	}
	return 0;
}