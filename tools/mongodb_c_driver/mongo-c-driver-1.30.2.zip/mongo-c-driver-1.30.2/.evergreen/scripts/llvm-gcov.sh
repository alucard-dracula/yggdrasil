#!/usr/bin/env bash

exec llvm-cov gcov "$@"
