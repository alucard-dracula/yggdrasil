:man_page: bson_string_append

bson_string_append()
====================

.. warning::
   .. deprecated:: 1.29.0

Synopsis
--------

.. code-block:: c

  void
  bson_string_append (bson_string_t *string, const char *str);

Parameters
----------

* ``string``: A :symbol:`bson_string_t`.
* ``str``: A string.

Description
-----------

Appends the ASCII or UTF-8 encoded string ``str`` to ``string``. This is not suitable for embedding NULLs in strings.

.. warning:: The length of the resulting string (including the ``NULL`` terminator) MUST NOT exceed ``UINT32_MAX``.
