#include <bson/bson.h>
#include <mongoc/mongoc.h>

int
main (void)
{
   return 0;
}
