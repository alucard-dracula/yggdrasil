/* Stub source so that CMake 3.18 and higher actually compile using the C++
 * compiler. CMake 3.18 started enforcing source type (e.g., "/TC" for C source
 * and "/TP" for C++ source) on the command line, forcing this as the
 * workaround. */

#include "pthread.c"
