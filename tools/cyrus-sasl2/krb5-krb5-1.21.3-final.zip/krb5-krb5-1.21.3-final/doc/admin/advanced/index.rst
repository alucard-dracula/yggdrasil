Advanced topics
===============


.. toctree::
   :maxdepth: 1

   retiring-des.rst
