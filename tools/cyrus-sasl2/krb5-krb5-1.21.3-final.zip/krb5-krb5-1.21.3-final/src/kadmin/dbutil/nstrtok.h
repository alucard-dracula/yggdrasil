/* -*- mode: c; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/* Prototype for nstrtok */
char *nstrtok(char *, const char *delim);
