// code which calls the actual example functions in turn

#ifndef _EXAMPLE_H
#define _EXAMPLE_H

#include "example_funcs.h"

// function which calls the actual example functions in turn
void CallAllExamples(const string &DSN_str);

#endif
