#ifndef _SHARECONN_H
#define _SHARE_CONN_H

#include "example_core.h"

// this function tests reading from a DBConnection that's created and shared
void SharedConnectionRead(const string &DSN);

#endif



