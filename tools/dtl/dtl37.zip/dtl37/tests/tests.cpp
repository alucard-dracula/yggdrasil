// Dummy files to get GNU make to auto-build the executable.
