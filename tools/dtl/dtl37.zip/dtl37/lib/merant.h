#ifndef DTL_MERANT_H
#define DTL_MERANT_H

// Merant licence stuff
//rc = SQLSetConnectAttr(hdbc, 1041, const_cast<TCHAR *>(_TEXT("IVZN.LIC")), 8 * sizeof(TCHAR)); 
//rc = SQLSetConnectAttr(hdbc, 1042, const_cast<TCHAR *>(_TEXT("IODBCDRIVERS0000049758QQ")), 24 * sizeof(TCHAR));

#endif
