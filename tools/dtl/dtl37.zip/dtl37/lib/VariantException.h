#ifndef DTL_VARIANT_EXCEPTION_H
#define DTL_VARIANT_EXCEPTION_H

#include "RootException.h"

// VariantException class moved to RootException.h
// to support ErrorHandler class

#endif
