该.vcxproj文件在被tool_update_vcxproj操作时会发生（无论修改成UTF8 和 BOM-UTF8）
1 使用VS启动 无论是DEBUG还是RELEASE都能正常运行
2 直接启动 DEBUG版本没问题 RELEASE版本会出现 

错误应用程序名称: tool_update_vcxproj.exe，版本: 0.0.0.0，时间戳: 0x662807eb
错误模块名称: MSVCR100.dll，版本: 10.0.40219.325，时间戳: 0x4df2bcac
异常代码: 0x40000015
错误偏移量: 0x00000000000761c9
错误进程 ID: 0x3b8c
错误应用程序启动时间: 0x01da95b61037f566
错误应用程序路径: E:\devel\yggr_workspace\yggdrasil\tool_update_vcxproj\tool_update_vcxproj.exe
错误模块路径: C:\Windows\SYSTEM32\MSVCR100.dll
报告 ID: 70c25ee9-c200-4d95-a11d-2a13b5e79992
错误程序包全名: 

这个问题是没有判断ptree的to_iterator是否有效引起的
